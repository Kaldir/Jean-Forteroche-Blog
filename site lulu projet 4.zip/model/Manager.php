<?php
namespace Kldr\Blog\Model;

class Manager
{
    protected function dbConnect()
    {
        $db = new \PDO('mysql:host=db706429770.db.1and1.com;dbname=db706429770;charset=utf8', 'dbo706429770', 'Hamsters1441!');
        return $db;
    }
}